document.addEventListener('DOMContentLoaded', function() {
  // DOM Elements
  const filterButtons = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  const galleryContainer = document.getElementById('gallery');
  
  // Category mapping to handle inconsistencies
  const categoryMap = {
    'waterfall': 'Tourism',
    'wildlife': 'wildlife',
    'Mask': 'Mask',
    'Local food': 'Local food',
    'Hotels': ['Hotel', 'Hotels'] // Handles both class names
  };
  
  // Initialize - show all items
  activateFilter('all');
  
  // Set up filtering with event delegation
  document.querySelector('.filters').addEventListener('click', function(e) {
    if (e.target.classList.contains('filter-btn')) {
      const filterValue = e.target.getAttribute('data-category');
      activateFilter(filterValue);
    }
  });
  
  // Filter activation function
  function activateFilter(filterValue) {
    // Update active button state
    filterButtons.forEach(btn => {
      const isActive = btn.getAttribute('data-category') === filterValue;
      btn.classList.toggle('active', isActive);
      btn.setAttribute('aria-pressed', isActive);
    });
    
    // Filter items
    galleryItems.forEach(item => {
      if (filterValue === 'all') {
        item.style.display = 'block';
      } else {
        const shouldShow = checkCategoryMatch(item, filterValue);
        item.style.display = shouldShow ? 'block' : 'none';
      }
    });
  }
  
  // Check if item matches category
  function checkCategoryMatch(item, filterValue) {
    if (!categoryMap[filterValue]) return false;
    
    const categoryClasses = categoryMap[filterValue];
    if (Array.isArray(categoryClasses)) {
      return categoryClasses.some(cls => item.classList.contains(cls));
    }
    return item.classList.contains(categoryClasses);
  }
  
  // Lightbox functionality
  const lightbox = createLightbox();
  let currentIndex = 0;
  let filteredItems = [];
  
  // Create lightbox DOM
  function createLightbox() {
    const lb = document.createElement('div');
    lb.className = 'lightbox';
    lb.setAttribute('role', 'dialog');
    lb.setAttribute('aria-modal', 'true');
    lb.setAttribute('aria-label', 'Image gallery lightbox');
    lb.innerHTML = `
      <button class="close-lightbox" aria-label="Close lightbox">&times;</button>
      <button class="lightbox-nav prev" aria-label="Previous image">&lt;</button>
      <button class="lightbox-nav next" aria-label="Next image">&gt;</button>
      <div class="lightbox-content">
        <img src="" alt="" role="presentation">
        <div class="lightbox-caption" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(lb);
    return lb;
  }
  
  // Gallery item click handler with event delegation
  galleryContainer.addEventListener('click', function(e) {
    const galleryItem = e.target.closest('.gallery-item');
    if (!galleryItem) return;
    
    // Don't open if clicked on a link
    if (e.target.tagName === 'A') return;
    
    // Get current filter state
    const activeFilter = document.querySelector('.filter-btn.active').getAttribute('data-category');
    
    // Get filtered items
    filteredItems = Array.from(galleryItems)
      .filter(item => {
        if (activeFilter === 'all') return true;
        return checkCategoryMatch(item, activeFilter);
      })
      .filter(item => item.style.display !== 'none');
    
    // Find clicked item index
    currentIndex = filteredItems.findIndex(item => item === galleryItem);
    
    // Update and show lightbox
    updateLightbox();
    showLightbox();
  });
  
  // Lightbox controls
  lightbox.querySelector('.close-lightbox').addEventListener('click', hideLightbox);
  lightbox.querySelector('.prev').addEventListener('click', showPrevImage);
  lightbox.querySelector('.next').addEventListener('click', showNextImage);
  
  // Lightbox visibility functions
  function showLightbox() {
    lightbox.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', handleKeyDown);
  }
  
  function hideLightbox() {
    lightbox.style.display = 'none';
    document.body.style.overflow = 'auto';
    document.removeEventListener('keydown', handleKeyDown);
  }
  
  // Navigation functions
  function showPrevImage() {
    currentIndex = (currentIndex - 1 + filteredItems.length) % filteredItems.length;
    updateLightbox();
  }
  
  function showNextImage() {
    currentIndex = (currentIndex + 1) % filteredItems.length;
    updateLightbox();
  }
  
  // Update lightbox content
  function updateLightbox() {
    if (filteredItems.length === 0) return;
    
    const currentItem = filteredItems[currentIndex];
    const imgSrc = currentItem.querySelector('img').src;
    const caption = currentItem.querySelector('h3').textContent;
    
    const lightboxImg = lightbox.querySelector('img');
    lightboxImg.src = imgSrc;
    lightboxImg.alt = caption; // Add proper alt text
    
    lightbox.querySelector('.lightbox-caption').textContent = caption;
    
    // Update aria-live for screen readers
    lightbox.querySelector('.lightbox-caption').setAttribute('aria-live', 'polite');
  }
  
  // Keyboard navigation
  function handleKeyDown(e) {
    switch(e.key) {
      case 'Escape':
        hideLightbox();
        break;
      case 'ArrowLeft':
        showPrevImage();
        break;
      case 'ArrowRight':
        showNextImage();
        break;
    }
  }
  
  // Close lightbox when clicking outside content
  lightbox.addEventListener('click', function(e) {
    if (e.target === lightbox) {
      hideLightbox();
    }
  });
});